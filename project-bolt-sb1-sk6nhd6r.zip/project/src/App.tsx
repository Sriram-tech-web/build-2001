import React, { useState } from 'react';
import {
  Layers,
  Wand2,
  Users,
  Cloud,
  Brain,
  ShoppingBag,
  Sparkles,
  ChevronRight,
  Play,
  Check,
  X,
  Maximize2,
  ChevronLeft,
  ChevronDown,
  Heart,
} from 'lucide-react';
import { supabase } from './lib/supabase';

function App() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [showGalleryModal, setShowGalleryModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [authType, setAuthType] = useState<'signup' | 'login'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [activeFeature, setActiveFeature] = useState(0);

  const validatePassword = (value: string) => {
    if (!/^[A-Z]/.test(value)) {
      setPasswordError('Password must start with a capital letter');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePassword(password)) {
      return;
    }

    try {
      if (authType === 'signup') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
      }
      
      setEmail('');
      setPassword('');
      setShowAuthModal(false);
    } catch (error) {
      console.error('Authentication error:', error);
      // Handle error appropriately
    }
  };

  const openAuth = (type: 'signup' | 'login') => {
    setAuthType(type);
    setShowAuthModal(true);
  };

  const galleryImages = [
    {
      url: "https://images.unsplash.com/photo-1599148400620-8e1ff0bf28d8?auto=format&fit=crop&w=800&q=80",
      title: "Sci-Fi Character",
      author: "John Doe",
      likes: 234
    },
    {
      url: "https://images.unsplash.com/photo-1599148401005-fe6d7497cb5e?auto=format&fit=crop&w=800&q=80",
      title: "Fantasy Warrior",
      author: "Jane Smith",
      likes: 189
    },
    {
      url: "https://images.unsplash.com/photo-1599148401079-a6cd53a1c1e0?auto=format&fit=crop&w=800&q=80",
      title: "Cyberpunk Hero",
      author: "Mike Johnson",
      likes: 312
    }
  ];

  const detailedFeatures = [
    {
      title: "Character Creation Suite",
      description: "Our advanced character creation tools provide everything you need to bring your ideas to life. From basic shapes to intricate details, craft your perfect character with precision and ease.",
      details: [
        "Intuitive drag-and-drop interface",
        "Real-time preview and editing",
        "Advanced morphing tools",
        "Custom texture mapping",
        "Pose library with hundreds of options"
      ]
    },
    {
      title: "AI-Powered Assistance",
      description: "Let our AI help you create stunning characters faster than ever. With smart suggestions and automated optimizations, you can focus on creativity while we handle the technical details.",
      details: [
        "Smart pose recommendations",
        "Automatic rigging system",
        "Style transfer technology",
        "Texture generation",
        "Animation assistance"
      ]
    },
    {
      title: "Professional Workflow",
      description: "A complete suite of professional tools designed for both individual artists and teams. Streamline your workflow and collaborate seamlessly with others.",
      details: [
        "Version control system",
        "Team collaboration tools",
        "Asset management",
        "Export to major 3D formats",
        "Render farm integration"
      ]
    }
  ];

  const nextGalleryImage = () => {
    setSelectedImage((prev) => (prev + 1) % galleryImages.length);
  };

  const prevGalleryImage = () => {
    setSelectedImage((prev) => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <header className="container mx-auto px-6 py-16">
        <nav className="flex items-center justify-between mb-16">
          <div className="flex items-center space-x-2">
            <Layers className="w-8 h-8 text-purple-500" />
            <span className="text-xl font-bold">CharacterForge</span>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="hover:text-purple-400 transition-colors">Features</a>
            <a href="#pricing" className="hover:text-purple-400 transition-colors">Pricing</a>
            <a href="#gallery" className="hover:text-purple-400 transition-colors">Gallery</a>
            <button 
              onClick={() => openAuth('signup')}
              className="bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-full transition-colors"
            >
              Get Started
            </button>
          </div>
        </nav>

        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="md:w-1/2">
            <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6">
              Create Stunning 3D Characters with Ease
            </h1>
            <p className="text-gray-300 text-lg mb-8">
              Professional-grade 3D character creation tools powered by AI. Design, customize, and share your characters in minutes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => openAuth('signup')}
                className="bg-purple-600 hover:bg-purple-700 px-8 py-3 rounded-full flex items-center justify-center transition-colors"
              >
                Start Creating Free <ChevronRight className="ml-2 w-5 h-5" />
              </button>
              <button 
                onClick={() => setShowDemoModal(true)}
                className="border border-white hover:bg-white/10 px-8 py-3 rounded-full flex items-center justify-center transition-colors"
              >
                Watch Demo <Play className="ml-2 w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1635360394882-6bf9ae9b6d3a?auto=format&fit=crop&w=800&q=80" 
              alt="Welcome Neon Sign"
              className="rounded-lg shadow-2xl w-full object-cover"
            />
          </div>
        </div>
      </header>

      {/* Detailed Features Section */}
      <section id="features" className="py-20 bg-gray-800/50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Discover Our Features</h2>
          <div className="grid lg:grid-cols-2 gap-12">
            <div className="space-y-6">
              {detailedFeatures.map((feature, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-xl transition-all duration-300 cursor-pointer ${
                    activeFeature === index
                      ? 'bg-purple-600 shadow-xl scale-105'
                      : 'bg-gray-800 hover:bg-gray-700'
                  }`}
                  onClick={() => setActiveFeature(index)}
                >
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-gray-300 mb-4">{feature.description}</p>
                  {activeFeature === index && (
                    <ul className="space-y-2">
                      {feature.details.map((detail, dIndex) => (
                        <li key={dIndex} className="flex items-center">
                          <Check className="w-5 h-5 text-purple-300 mr-2" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1615796153287-98eacf0abb13?auto=format&fit=crop&w=800&q=80"
                alt="Feature Preview"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent rounded-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Featured Creations</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {galleryImages.map((image, index) => (
              <div
                key={index}
                className="group relative overflow-hidden rounded-xl cursor-pointer"
                onClick={() => {
                  setSelectedImage(index);
                  setShowGalleryModal(true);
                }}
              >
                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-xl font-bold mb-1">{image.title}</h3>
                    <p className="text-gray-300">by {image.author}</p>
                  </div>
                  <button className="absolute top-4 right-4 p-2 bg-white/20 rounded-full backdrop-blur-sm">
                    <Maximize2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Choose Your Plan</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Starter",
                price: "Free",
                features: [
                  "Basic character creation tools",
                  "5 base models",
                  "Community support",
                  "1GB cloud storage",
                  "Export in standard quality"
                ]
              },
              {
                name: "Pro",
                price: "$29/month",
                features: [
                  "Advanced design tools",
                  "Unlimited base models",
                  "Priority support",
                  "50GB cloud storage",
                  "High-quality exports",
                  "Team collaboration"
                ]
              },
              {
                name: "Enterprise",
                price: "Custom",
                features: [
                  "All Pro features",
                  "Custom base models",
                  "Dedicated support",
                  "Unlimited storage",
                  "API access",
                  "Custom branding"
                ]
              }
            ].map((plan, index) => (
              <div key={index} className="bg-gray-800 p-8 rounded-xl hover:bg-gray-700 transition-colors">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-4xl font-bold text-purple-500 mb-6">{plan.price}</p>
                <ul className="space-y-4">
                  {plan.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-purple-500 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => openAuth('signup')}
                  className="w-full mt-8 bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-full transition-colors"
                >
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-purple-600">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6">Start Creating Today</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of creators and bring your characters to life with CharacterForge.
          </p>
          <button 
            onClick={() => openAuth('signup')}
            className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-3 rounded-full transition-colors"
          >
            Start Your Free Trial
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Layers className="w-6 h-6 text-purple-500" />
                <span className="text-lg font-bold">CharacterForge</span>
              </div>
              <p className="text-gray-400">
                Professional 3D character creation platform for creators of all skill levels.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#features" className="hover:text-purple-400">Features</a></li>
                <li><a href="#pricing" className="hover:text-purple-400">Pricing</a></li>
                <li><a href="#gallery" className="hover:text-purple-400">Gallery</a></li>
                <li><a href="#marketplace" className="hover:text-purple-400">Marketplace</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#docs" className="hover:text-purple-400">Documentation</a></li>
                <li><a href="#tutorials" className="hover:text-purple-400">Tutorials</a></li>
                <li><a href="#blog" className="hover:text-purple-400">Blog</a></li>
                <li><a href="#support" className="hover:text-purple-400">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#about" className="hover:text-purple-400">About</a></li>
                <li><a href="#careers" className="hover:text-purple-400">Careers</a></li>
                <li><a href="#contact" className="hover:text-purple-400">Contact</a></li>
                <li><a href="#privacy" className="hover:text-purple-400">Privacy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 CharacterForge. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 p-8 rounded-xl max-w-md w-full">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold">{authType === 'signup' ? 'Create Account' : 'Welcome Back'}</h3>
              <button 
                onClick={() => setShowAuthModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleAuth} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    validatePassword(e.target.value);
                  }}
                  className={`w-full px-4 py-2 bg-gray-700 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
                    passwordError ? 'border-red-500' : 'border-gray-600'
                  }`}
                  required
                />
                {passwordError && (
                  <p className="text-red-500 text-sm mt-1">{passwordError}</p>
                )}
              </div>
              <button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-full transition-colors"
              >
                {authType === 'signup' ? 'Create Account' : 'Sign In'}
              </button>
            </form>
            <p className="mt-4 text-center text-gray-400">
              {authType === 'signup' ? 'Already have an account?' : "Don't have an account?"}{' '}
              <button
                onClick={() => setAuthType(authType === 'signup' ? 'login' : 'signup')}
                className="text-purple-400 hover:text-purple-300"
              >
                {authType === 'signup' ? 'Sign In' : 'Sign Up'}
              </button>
            </p>
          </div>
        </div>
      )}

      {/* Demo Video Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 p-4 rounded-xl max-w-4xl w-full">
            <div className="flex justify-end mb-2">
              <button 
                onClick={() => setShowDemoModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="relative pt-[56.25%]">
              <iframe
                className="absolute inset-0 w-full h-full rounded-lg"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                title="Product Demo"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* Gallery Modal */}
      {showGalleryModal && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center p-4 z-50">
          <div className="relative w-full max-w-6xl">
            <button 
              onClick={() => setShowGalleryModal(false)}
              className="absolute -top-12 right-0 text-white/80 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="relative">
              <img
                src={galleryImages[selectedImage].url}
                alt={galleryImages[selectedImage].title}
                className="w-full rounded-lg"
              />
              <button
                onClick={prevGalleryImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full backdrop-blur-sm hover:bg-white/30 transition-colors"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextGalleryImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full backdrop-blur-sm hover:bg-white/30 transition-colors"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
            <div className="mt-4 text-center">
              <h3 className="text-2xl font-bold">{galleryImages[selectedImage].title}</h3>
              <p className="text-gray-400">by {galleryImages[selectedImage].author}</p>
              <div className="mt-2 flex items-center justify-center space-x-4">
                <span className="flex items-center">
                  <Heart className="w-5 h-5 text-red-500 mr-1" />
                  {galleryImages[selectedImage].likes}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;