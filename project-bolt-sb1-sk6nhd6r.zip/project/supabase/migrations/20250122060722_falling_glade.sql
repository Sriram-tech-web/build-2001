/*
  # Add Password Validation

  1. Changes
    - Add password validation trigger to enforce first letter capitalization
    - Add helper function to check password format

  2. Security
    - Maintains existing RLS policies
    - Adds server-side validation
*/

-- Create password validation function
CREATE OR REPLACE FUNCTION validate_password()
RETURNS trigger AS $$
BEGIN
  -- Check if the first character is uppercase
  IF NOT (NEW.raw_user_meta_data->>'password' ~ '^[A-Z]') THEN
    RAISE EXCEPTION 'Password must start with a capital letter';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger to auth.users
CREATE TRIGGER ensure_valid_password
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION validate_password();